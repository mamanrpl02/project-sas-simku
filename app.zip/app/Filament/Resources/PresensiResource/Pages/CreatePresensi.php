<?php

namespace App\Filament\Resources\PresensiResource\Pages;

use App\Filament\Resources\PresensiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePresensi extends CreateRecord
{
    protected static string $resource = PresensiResource::class;
}
