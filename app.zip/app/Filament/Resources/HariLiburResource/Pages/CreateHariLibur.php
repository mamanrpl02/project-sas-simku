<?php

namespace App\Filament\Resources\HariLiburResource\Pages;

use App\Filament\Resources\HariLiburResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateHariLibur extends CreateRecord
{
    protected static string $resource = HariLiburResource::class;
}
