<?php

namespace App\Filament\Resources\PengeluaranKasResource\Pages;

use App\Filament\Resources\PengeluaranKasResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePengeluaranKas extends CreateRecord
{
    protected static string $resource = PengeluaranKasResource::class;
    
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
