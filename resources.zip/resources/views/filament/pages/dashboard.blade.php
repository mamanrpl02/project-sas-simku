<x-filament-panels::page>
    {{-- @livewire(\App\Livewire\Dashboard\PostsChart::class) --}}
</x-filament-panels::page>
